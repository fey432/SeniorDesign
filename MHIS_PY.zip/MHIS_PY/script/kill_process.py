import os
import time

def killprocess(pid_number):
    time.sleep(1)
    os.system("taskkill /F /PID " + pid_number)